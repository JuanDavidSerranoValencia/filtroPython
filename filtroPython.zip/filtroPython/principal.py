import os 
import cita
from cita import dicCitas

if __name__ == "__main__":
    flagPrincipal= True
    while flagPrincipal:
        os.system("clear")
        print("Menu Principal".center (50,"-"))
        print ("1.Agregar Cita \n2.Buscar Cita \n3.Modificar Cita\n4.Cancelar Cita \n5.Salir del programa")
        try:
            opc = int( input ( "Ingrese la opcion que desea realizar:"))
        except Exception:
            print("Porfavor Ingrese valores validos.")
        else:
            if( opc ==1):
                print(dicCitas)
                cita.crearCita()
            elif ( opc == 2):
                cita.buscarCita()
            elif( opc == 3):
                cita.editarCita()
            elif(opc == 4):
                cita.eliminarCita()
            elif(opc==5):
                flagPrincipal = False
            else:
                print("Ingrese una opcion valida")