import json

def crearJson (nombre,data):
    file = open(nombre,"w") 
    obj=json.dumps(data,indent=4)
    file.write(obj)
    file.close()

def loadJson(nombre):
    file = open(nombre,"r")
    data = json.load(file)
    file.close()
    return data

def checkJson(nombre):
    try:
        with open(nombre,"r") as f:
            return True
    except IOError as r:
        return False
    except FileNotFoundError as e:
        print("error")

