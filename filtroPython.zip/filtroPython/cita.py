import os
import core
from datetime import datetime
fechaLocal = datetime.now()
dicCitas={'citas':[]}

def crearCita():
    os.system("clear")
    print("AGREGAR CITA".center(50,"-"))
    try:
        cita ={
          
                "nombre":input("Ingrese el nombre del usuario:").upper(),
                "fecha":input("Ingrese la fecha para la cita (yy-mm-dd):"),
                "hora":input("Ingrese la hora de la cita:"),
                "motivo":input("ingrese el motivo de su cita:")
            }

    except Exception:
        print("Ingrese valores validos para cada uno de los datoss pedidos.")
        f= bool(input("\npresione enter para continuar"))
    else:
        dicCitas["citas"].append(cita)
        
        if core.checkJson("cita.json")== True:
            data= core.loadJson("cita.json")
            data["citas"].append(cita)
            core.crearJson("cita.json",data)
            
        else:
            core.crearJson("cita.json",dicCitas)
        print("Cita registrada con exito.")
        f= bool(input("\npresione enter para continuar"))


def buscarCita ():
    os.system("clear")
    print("BUSCAR CITA".center(50,"-"))
    listaUser =[]
    try:
        nombreBuscar = input("Ingrese el nombre del paciente al que desea buscar citas:").upper()
    except Exception:
        print("Ingrese valores validos para el nombre del usuario.")
        f= bool(input("\npresione enter para continuar"))
    else:
        for i ,item in enumerate(dicCitas["citas"]):
            if (nombreBuscar  == item ["nombre"]):
                listaUser.append(item)
        if (len(listaUser) >0):
            print(f"Lista de citas para el usuario {item['nombre']}")
            for i, item in enumerate(listaUser):
                print(f"{i+1}-'Nombre Paciente:'{item['nombre']}-'Fecha Cita:'{item['fecha']}-'Hora Cita:'{item['fecha']}-'Motivo de consulta:'{item['motivo']}")
            f= bool(input("\npresione enter para continuar"))   
        else:
            print("el nombre ingresado no tiene citas disponibles")
            f= bool(input("\npresione enter para continuar"))
    

def editarCita():
    os.system("clear")
    print("EDITAR CITA".center(50,"-"))
    listaUser =[]
    try:
        nombreBuscar = input("Ingrese el nombre del paciente al que desea editar citas:").upper()
    except Exception:
        print("Ingrese valores validos para el nombre del usuario.")
        f= bool(input("\npresione enter para continuar"))
    else:
        for i ,item in enumerate(dicCitas["citas"]):
            if (nombreBuscar  == item ["nombre"]):
                listaUser.append(item)

        if (len(listaUser) >0):
            print(f"Lista de citas para el usuario {item['nombre']}")
            for i, item in enumerate(listaUser):
                 print(f"{i+1}-'Nombre Paciente:'{item['nombre']}-'Fecha Cita:'{item['fecha']}-'Hora Cita:'{item['fecha']}-'Motivo de consulta:'{item['motivo']}")
            try:
                citaEditar= listaUser[int(input("Ingrese el numero de la cita que desea actualizar:"))-1]
                citaEditar["fecha"] = input("Ingrese una nueva fecha o presione enter para omitr:") or citaEditar["fecha"]
                citaEditar["hora"] = input("Ingrese una nueva hora o presione enter para omitr:") or citaEditar["hora"]
                citaEditar["motivo"] = input("Ingrese un nuevo motivo o presione enter para omitr:") or citaEditar["motivo"]
            except Exception:
                print("Ingrese valores validos")
            else:
                core.crearJson("cita.json",dicCitas)
                print("Cita edita con exito.")
                f= bool(input("\npresione enter para continuar"))
        else:
            print("el nombre ingresado no tiene citas disponibles")
            f= bool(input("\npresione enter para continuar"))



def eliminarCita():
    os.system("clear")
    print("ELIMINAR CITA".center(50,"-"))
    listaUser =[]
    try:
        nombreBuscar = input("Ingrese el nombre del paciente al que desea eliminar cita:").upper()
    except Exception:
        print("Ingrese valores validos para el nombre del usuario.")
        f= bool(input("\npresione enter para continuar"))

    else:
        for i ,item in enumerate(dicCitas["citas"]):
            if (nombreBuscar  == item ["nombre"]):
                listaUser.append(item)

        if (len(listaUser) >0):
            print(f"Lista de citas para el usuario {item['nombre']}")
            for i, item in enumerate(listaUser):
                 print(f"{i+1}-'Nombre Paciente:'{item['nombre']}-'Fecha Cita:'{item['fecha']}-'Hora Cita:'{item['fecha']}-'Motivo de consulta:'{item['motivo']}")
            try:
                dicCitas["citas"].remove(listaUser[int(input("Ingrese el numero de la cita que desea eliminar:"))-1])
            except  Exception:
                print("Ingrese datos validos.")
                f= bool(input("\npresione enter para continuar"))

            else:
                core.crearJson("cita.json",dicCitas)
                print("Cita eliminada con exito.")
                f= bool(input("\npresione enter para continuar"))

        else:
            print("el nombre ingresado no tiene citas disponibles")
            f= bool(input("\npresione enter para continuar"))
